

DRIVERS = list()
HUB_URL = 'http://selenium-hub:4444/wd/hub'
RARITY_BASE_URL = 'https://rarity.tools'
